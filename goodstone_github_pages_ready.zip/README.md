# Goodstone Investor Reporting Demo

This folder is ready to publish with GitHub Pages.

## Publish

1. Create a new GitHub repository.
2. Upload **all four files in this folder to the repository root**.
3. In GitHub, go to **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then click **Save**.
6. Open the Pages URL after the deployment completes.

`index.html` is the investor-reporting demo. `scope-and-fee.html` is the proposal.

The demo is front-end only. Its Google Drive and AI actions are simulated and do not contain API credentials.
